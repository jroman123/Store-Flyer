//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\ README FILE - 7/23/2016 - "Single Page Store Flyer" - Flyer Android App
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

A. DISCLAIMER
This disclaimer appoints that the content provided in this app is based on personal opinions and theories, and in no circumstance be utilized as factual content unless proven by an expert in the field of the subject.
This app was developed for educational purposes and to share a personal inside on the subject. Store app is not responsible for, and expressly disclaims all liability for, damages of any kind arising out of use, reference to, or reliance on any information contained within the app.

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

B. CONTENT
Topic --> Tigerdirect Store Flyer

This App portraits the theme, location and breif description of a retail/online store of electronis and computer devices.
By pressing title image, user can be redirected to the store's web page.

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

C. OPERATIONAL ALGORITHM
1. Open App
2. View content
3. If interested, click on title image and be redirected to the company's official web page
4. Exit App

//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------

D. ALGORITHM HIERARCHY

                                                                         +----------+
									 | OPEN APP |
									 +----------+
									       ^
								      	       |
								        +--------------+	   
									|  SCROLL DOWN |
                                                                        +--------------+
                                                                               ^
                                                                               |
									+------------------+      +----------+
									| CICK TITLE IMAGE |------| EXIT APP |
									+------------------+      +----------+   
								                ^
                                                                                |											
                                                               +----------------------------------+		
							       |  REDIRECTED TO ACS OFFICIAL SITE |
						       	       +----------------------------------+
								
//---------------------------------------------------------------------------------------------------------------------------------------------------------------
\\
//---------------------------------------------------------------------------------------------------------------------------------------------------------------
									   
RESOURCES
https://www.tigerdirect.com
