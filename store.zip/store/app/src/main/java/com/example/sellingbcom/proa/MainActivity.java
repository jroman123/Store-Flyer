package com.example.sellingbcom.proa;

import android.app.Activity;
import android.app.Dialog;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

/**
 * SHOW DIALOG BOX
 */
public class MainActivity extends Activity {

    TextView introText, content1Text, content2Text, content3Text, content4Text, content5Text, conclusionText;
    ImageButton showIntro, hideIntro, showContent1, hideContent1, showContent2, hideContent2, showContent3, hideContent3, showContent4, hideContent4, showContent5, hideContent5, showConclusion, hideConclusion;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
    }

    /**
     * GET DIALOG BOX TO VIEW
     *
     * @param view
     */
    public void submit(View view) {
        CustomDialogClass cdd = new CustomDialogClass(MainActivity.this);
        cdd.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        cdd.show();
    }

    /**
     * START DIALOG BOX
     */
    public class CustomDialogClass extends Dialog implements
            android.view.View.OnClickListener {

        public Activity c;
        public Dialog d;
        public Button yes, no;

        public CustomDialogClass(Activity a) {
            super(a);
            // TODO Auto-generated constructor stub
            this.c = a;
        }

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            requestWindowFeature(Window.FEATURE_NO_TITLE);
            setContentView(R.layout.dialog_demo);
            yes = (Button) findViewById(R.id.btn_yes);
            no = (Button) findViewById(R.id.btn_no);
            yes.setOnClickListener(this);
            no.setOnClickListener(this);

        }
//SWITCH CASE INSTED OF IF

        /**
         * BUT IF ELSE OPTION WAS USED THEN
         * public void onClick(View v) {
         * if(v.getId() == R.id.btn_yes) {
         * <p/>
         * String url = "http://www.cancer.org/index";
         * Intent i = new Intent(Intent.ACTION_VIEW);
         * i.setData(Uri.parse(url));
         * startActivity(i);
         * // c.finish();
         * <p/>
         * }else if (v.getId() == R.id.btn_no){
         * <p/>
         * dismiss();
         * <p/>
         * }else{
         * <p/>
         * dismiss();
         * <p/>
         * }
         * }
         */
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.btn_yes:
                    //IF RETURN IS TRUE USER IS REDIRECTED TO SITE
                    String url = "http://www.tigerdirect.com";

                    Intent i = new Intent(Intent.ACTION_VIEW);
                    i.setData(Uri.parse(url));
                    startActivity(i);

                    // c.finish();
                    break;
                case R.id.btn_no:
                    //IF RETURN IS FALSE USER STAYS ON THE APP
                    dismiss();
                    break;
                default:
                    break;
            }
            dismiss();
        }
    }
}